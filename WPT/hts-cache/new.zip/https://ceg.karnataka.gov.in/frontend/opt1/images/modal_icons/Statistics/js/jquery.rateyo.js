﻿

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centre for e-Governance</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="https://kit.fontawesome.com/8e9180aad7.js" crossorigin="anonymous"></script>
    
  <link rel="icon" href="images/kar_main_logo.png" type="image/png" sizes="42x42"/>

  
      <!-- Template Stylesheet -->
      <link href="css/animate.min.css" rel="stylesheet">
   
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css">
    <script src="js/jquery.rateyo.js"></script>
    <script src="js/main.js"></script>
    
    <link href="css/jquery.rateyo.css" rel="stylesheet">
    
  <link rel="stylesheet" type="text/css" href="owl/owl.carousel.css">

    <!--------------------------------------------->
    <link rel="stylesheet" type="text/css" href="css/mystyle.css" />  
    <link rel="stylesheet" type="text/css" href="css/laptop.css">
    <link rel="stylesheet" type="text/css" href="css/tablet.css">
    <link rel="stylesheet" type="text/css" href="css/mobile.css" />
    <link rel="stylesheet" type="text/css" href="css/small_mobile.css">
</head>
<body>

<!--------------------------------------------->
  <!-- Modal -->
  <div class="modal " id="myModal_screen" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Screen Reader Access </h4>
        </div>
        <div class="modal-body" style="overflow-x: auto;">
          
          <div class="nicetext">        
            <div class="innerpage">
             <div id="skipCont" class="wrapper">
       
             <div class="row">                 
              <div class="col-md-12 col-sm-9 col-xs-12">
                <h1 class="heading" tabindex="0"></h1>
                <div class="region region-content">
                <div id="block-system-main" class="block block-system">
  
    
                <div class="content">
                 <div class="panel-display panel-1col clearfix">
                 <div class="panel-panel panel-col">
                   <div>
                    <div class="panel-pane pane-views pane-page">
  
                     <div class="pane-content">
                       <div class="view view-page view-id-page view-display-id-block view-dom-id-9f59a9bf8ad69ecc93f01660ca78bb00">
        
                       <div class="view-content">
                        <div class="views-row views-row-1 views-row-odd views-row-first views-row-last">
      
                         <div class="views-field views-field-body">        
                          <div class="field-content">
                            
                              <p class="web">The website complies with World Wide Web Consortium (W3C) Web Content Accessibility Guidelines (WCAG) 2.0 level AA. This will enable people with visual impairments access the website using assistive technologies, such as screen readers. The information of the website is accessible with different screen readers, such as JAWS, NVDA, SAFA, Supernova and Window-Eyes.</p>
                              <p class="web">Following table lists the information about different screen readers:</p>
                            </p>
  
                        
  
                            <div class="scroll-table1">  
                              <table class="table table-bordered table-striped" summary="Screen Reader">
                                <tbody>
                                  <tr>
                                    <th>Sl. No.</th>
                                    <th>Screen Reader</th>
                                    <th>Website</th>
                                    <th>Free/ Commercial</th>
                                  </tr>
  
  
                                  <tr>
                                    <td>1</td>
                                    <td>Non Visual Desktop Access (NVDA)</td>
                                    <td><a href="https://www.nvda-project.org/" target="_blank">https://www.nvda-project.org/</a><br> (External website that opens in a new window)</td>
                                    <td>Free</td>
                                  </tr>
  
                                  <tr>
                                    <td>2</td>
                                    <td>JAWS</td>
                                    <td><a href="https://www.freedomscientific.com/products/software/jaws/" target="_blank">https://www.freedomscientific.com</a> <br>(External website that opens in a new window)</td>
                                    <td>Commercial</td>
                                  </tr>
  
                                  <tr>
                                    <td>3</td>
                                    <td>Window-Eyes</td>
                                    <td><a href="https://www.gwmicro.com/Window-Eyes/" target="_blank">https://www.gwmicro.com</a><br> (External website that opens in a new window)</td>
                                    <td>Commercial</td>
                                  </tr>
  
                                  <tr>
                                    <td>4</td>
                                    <td>System Access To Go</td>
                                    <td><a href="https://www.satogo.com/" target="_blank">https://www.satogo.com/</a><br>(External website that opens in a new window)</td>
                                    <td>Free</td>
                                  </tr>
  
                                  <tr>
                                    <td>5</td>
                                    <td>WebAnywhere</td>
                                    <td><a href="https://webinsight.cs.washington.edu/" target="_blank">https://webinsight.cs.washington.edu/</a> <br>(External website that opens in a new window)</td>
                                    <td>Free</td>
                                  </tr>

                                  <tr>
                                    <td>6</td>
                                    <td>atoall</td>
                                    <td><a title="Opens in a new window" target="_blank" rel="noopener" href="https://atoall.com/all.asp"> <img height="64" width="64" alt="This Will Make You Easy For Growth, Use Accessibility Tool" src="https://atoall.com/all/512-accessibility-square.svg"></a>
 <br>(External website that opens in a new window)</td>
                                    <td>Free</td>
                                  </tr>
  
                                </tbody>
                              </table>
                            </div>
                          </div>  
                        </div>  
                      </div>
                    </div>
  
                </div>  
               </div>
  
              </div>
              </div>
              </div>
             </div>
             </div>
             </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
  
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<!------------------------------------------------->
<section class="header">
  <div class="container newheader">
      <div class="row screen">
          <div class="col-md-6" id="head_col1">
           
              <ul class="list-inline" id="ul_left">
                  <li><img src="images/kannada-icon.png" class="kaimg"/><a href="knindex.php" class="kan"> Kannada</a></li>  
                  <li class="hidden-sm"><a href="https://karnataka.gov.in/english" target="_blank" class="kan1">
            <img src="images/kar_main_logo.png" class="mainlogo"/>Official Website of GoK</a></li>  
                  <li class="hidden-xs" data-toggle="modal" data-target="#myModal_screen">
                    <p class="kan d-none d-sm-block">Screen reader access</p></li>

                    <li class="hidden-xs" data-toggle="modal" data-target="#myModal_screen">
                    <i class="fa-solid fa-universal-access response-icon d-sm-block d-md-none"></i></li>

                 
        
              </ul>   
          </div>

          <div class="col-md-6"  id="head_col2">
              <ul class="list-inline" id="ul_right">
                  <div class="icons">
                  <li><a href="#" class="A_white"><i class="fa fa-moon singleicon"></i></a></li>
                  <li><a href="#" class="A_black"><i class="fa fa-sun singleicon-active"></i></a></li>
              </div>

              <div class="textcontrols">
              <a href="javascript:;" class="changer" title="Decrease Text" id="decreasetext"><span>A<sup>-</sup></span>
              </a><a href="javascript:;" class="changer" id="resettext"><span>A</span></a>
            <a href="javascript:;" class="changer" id="increasetext"><span>A<sup>+</sup></span></a>

          </div>

               

              </ul>
          </div>
      </div>
  </div>
</section>

 <!--------------------------------------------->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" aria-label="Main navigation">
    <div class="container newheader">
    
      <a class="navbar-brand" href="index.php"><img src="images/dept_logo.png" class="dept_logo"/></a>
      <div class="con">
      <h3 class="gov">Centre for e-Governance</h3>
     <p class="karnataka">Government Of Karnataka</p>
    </div>
 
      <button class="navbar-toggler p-0 border-0" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false"
              aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
  
      <div class="collapse navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto mb-2 mb-lg-0">
          <li class="nav-item active">
            <a class="nav-link" aria-current="page" href="index.php"><i class="fa-solid fa-house"></i></li></a>
          </li>


          <div class="dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown1" data-flip="false"
               data-toggle="dropdown" aria-expanded="false">     <button class="dropbtn">About CeG</button></a>
               <div class="dropdown-content">
               <a class="dropdown-item" href="vision.html">Vision/Mission</a>
                  <a class="dropdown-item" href="awards.html">Awards & Achievements</a>
                   <a class="dropdown-item" href="gallery.html"> Strategy Gallery</a>
                 
               </div>
            </div>

            <div class="dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown1" data-flip="false"
                 data-toggle="dropdown" aria-expanded="false">     <button class="dropbtn">Important Links</button></a>
                 <div class="dropdown-content">
                  <a class="dropdown-item" href="https://egovernance.karnataka.gov.in/english" target="_blank"> DPAR e-Governance</a>
                  <a class="dropdown-item" href="https://karunadu.karnataka.gov.in/edcs/Pages/home.aspx" target="_blank"> EDCS</a>
                   <a class="dropdown-item" href="https://www.meity.gov.in/" target="_blank"> Ministry of Electronics and Information Technology (MeitY)</a>
                   
                 </div>
              </div>

              <div class="dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dropdown1" data-flip="false"
                   data-toggle="dropdown" aria-expanded="false"><button class="dropbtn">RTI</button></a>
                   <div class="dropdown-content">
                   <a class="dropdown-item" href="https://rtionline.karnataka.gov.in/index.php?lan=E" target="_blank">  ONLINE RTI</a>
                    <a class="dropdown-item" href="rti.html">RTI 26(3)(B)</a>
                     <a class="dropdown-item" href="pdf/rti.pdf" target="_blank"> RTI 4(1)(A)</a>
                     
                   </div>
                </div>

                <div class="dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="dropdown1" data-flip="false"
                     data-toggle="dropdown" aria-expanded="false">     <button class="dropbtn">Website User Manual</button></a>
                     <div class="dropdown-content">
                      <a class="dropdown-item" href="pdf/version1.pdf" target="_blank">Version-1</a>
                      <a class="dropdown-item" href="pdf/version2.pdf" target="_blank">Version-2</a>
                       
                     </div>
                  </div>
				  
				   <li class="nav-item active">
            <a class="nav-link" aria-current="page" href="media.html" style="font-weight:500;font-size:16px;">Media</li></a>
          </li>


         <div class="vl"></div> 
          <li class="nav-item cw">
            <a target="_blank" href="Blog/public" class="button">Blog</a>
          </li>
          <li class="nav-item cw">
            <a href="contact.html" class="button">Contact Us</a>
          </li>


                </ul>
              </li>
            </ul>
          </li>
        </ul>
    
      </div>
    </div>

  </nav>   <!---------------------------------------------->
 
  <!--------------------------------->
<section class="navheader">

<div class="container-fluid">

  <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      
	  
	    <div class="item active">
        <img src="images/banner2.jpg" alt="Los Angeles" style="width:100%;">
      </div>

      <div class="item">
        <div class="col-md-12 row">
        <div class="col-md-4 socialslide">
          <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-f1970cbf-5b77-4ccb-b40a-2bd18925912b"></div>


        </div>
        <div class="col-md-4 socialslide">
          <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/kn_IN/sdk.js#xfbml=1&version=v17.0" nonce="tlQPsBin"></script>

<div class="fb-page" data-href="https://www.facebook.com/ceg.karnataka" data-tabs="timeline" data-width="33.33%" data-height="800px" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/ceg.karnataka" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/ceg.karnataka">Centre for e-Governance Karnataka</a></blockquote></div>

        </div>
        <div class="col-md-4 socialslide">
          <a class="twitter-timeline" href="https://twitter.com/ceg_karnataka?ref_src=twsrc%5Etfw">Tweets by ceg_karnataka</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
        </div>
        </div>
      </div>
    
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


  </div>
</section>

<!----------------------------------->

<section class="flatheader">
<div class="container newheader wow fadeInUp" data-wow-delay="0.1s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;">
  <div class="grid style2 aos-init aos-animate" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="200">
     
      <div class="grid-card">
          <span class="grid-icon">
              <i class="flaticon-volunteer"> <img src="images/newabt.jpg" class="abt"/></i>
          </span>
          <h3>About Us</h3>
          
          <a href="about.html" class="link style1">Read More <i class="flaticon-right-arrow"></i></a>
      </div>
     
      <div class="grid-card">
          <span class="grid-icon">
              <i class="flaticon-coin"> <img src="images/newmessage.jpg" class="abt"/></i>
          </span>
          <h3>Organization chart</h3>
          <a href="organization.html" class="link style1">Read More<i class="flaticon-right-arrow"></i></a>
      </div>

      <div class="grid-card">
        <span class="grid-icon">
            <i class="flaticon-money-box"> <img src="images/new3.jpg" class="abt"/></i>
        </span>
        <h3>Message</h3>
        <a href="message.html" class="link style1">Read More<i class="flaticon-right-arrow"></i></a>
    </div>
  </div>


</div>

</section>
<!--onclick="window.open('/pdf/Extension_Letter.pdf');"-->
<marquee class="marquee" behavior="scroll" direction="left" style="padding:10px;color:#fff;background:#A7CF38;font-size:16px;"><a style="color:#fff;" target="_blank" href="/pdf/Extension of time for the submission of application for the post of PD KSWAN on Deputation Bases-1.pdf" >"Advertisement to fill the post of Project Director, KSWAN on deputation"</a></marquee>  <!------------------------------------------->
 

 <section class="flatheader">
    <div class="container newheader1">
           

  <div class="row sec-row">
    <div class="col-md-5 ">
      <img src="images/dept.jpg" class="city rounded w-75 wow zoomIn" style="visibility: hidden; animation-name: none;" />
    </div>
    <div class="col-md-7 city-div  wow fadeInUp" data-wow-delay="0.1s" style="visibility: hidden; animation-delay: 0.2s; animation-name: none;">
      <p class="ceg">CeG</p>
      <h1 class="governance">Centre for e-Governance</h1>
      <p class="kar">Centre for e-Governance (CeG) was established in the year 2006 by the Department of Personnel and Administrative Reforms (DPAR), Government of Karnataka. It is an autonomous and independent body set up for conceptualizing, implementing and monitoring various e-Governance initiatives in Karnataka. The Centre for e-Governance has been established under the Karnataka Societies Registration Act, 1960. Its area of operation is spread across the entire State of Karnataka.</p>
    <p class="kar">The Centre for e-Governance is unique as it is placed under Department of Personnel & Administrative Reforms (DPAR) which directly reports to the Hon’ble Chief Minister. Ever since its inception, CeG has contributed immensely by helping citizens of Karnataka to reap the benefits of Information and Technology (IT).  </p>
   
    <a href="about.html" class="button1">Read More</a>
    <i class="fa fa-play-circle icon"> <span class="watch1">Watch Video<hr class="line"></span></i>
    </div>
  </div>
    </div>
  </section>
<!---------------------------------------------->
   <Section class="third-con">
    <div class="container newheader2  wow fadeInUp" data-wow-delay="0.1s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;">

      <div class="btm">
      
        <div class="row sec-row">
      
         <div class="col-md-4 num">
            <div class="first">
              <h1 class="govt">
              <h3 class="tab_head">
              <div id="counter">
                  <!-- counts -->
              </div></h3>
             </h1><br/>
              <p class="total">Total Number of<br/>  Projects</p></div>
          </div>
      
          <div class="col-md-4 num1">
            <div class="sec">
              <h1 class="govt">
              <h3 class="tab_head">
              <div id="counter1">
                      <!-- counts -->
                  </div></h3>
              </h1><br/>
              <p class="total">Govt to Govt<br/>  Projects</p></div>
          </div>
      
          <div class="col-md-4 num2">
            <div class="third">
              <h1 class="govt">
                <h3 class="tab_head">
                <div id="counter2">
                  <!-- counts -->
              </div></h3>
              </h1><br/>
              <p class="total">Govt to Public/Company <br/> Projects</p></div>
          </div>
      
       
      
      </div>

      

      <h1 class="governance1">Centre for e-Governance Projects</h1>

      <div class="row sec-row">

      <div class="col-md-8">
        <a href="https://cropsurvey.karnataka.gov.in" target="_blank"> 
       <img src="images/dept_img/enimages/Crop survey.jpg" class="bigimg w-100 wow zoomIn"  style="visibility: hidden; animation-name: none;"/></a>
      </div>

      <div class="col-md-4">

        <a href="https://eofficecitizen.karnataka.gov.in/en" target="_blank">
        <img src="images/dept_img/enimages/E-Office.jpg" alt="eoffice" class="img1 w-50 wow zoomIn" data-wow-delay="0.3s" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/></a>

        <a href="https://webportal.karnataka.gov.in/en" target="_blank">
        <img src="images/dept_img/enimages/Web POrtal.jpg" alt="webportal" class="img2 w-75 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/></a>
        
       </div>


      </div>
   </Section>

  <!------------------------------------------->
  <Section class="fourth-con">
    <div class="container newheader5">
        <div class="row sec-row">

          <div class="col-md-4">
            <a href="https://karnataka.data.gov.in/" target="_blank">
            <img src="images/dept_img/enimages/KODI.jpg" alt="Kodi" class="img4 w-100 wow zoomIn" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/>
          </a>
          </div>

          <div class="col-md-4">
            <a href="https://www.digilocker.gov.in/" target="_blank">
            <img src="images/dept_img/enimages/Digi.jpg" class="img5 w-50 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/>
          </a>
          </div>

          <div class="col-md-4">
            <a href="https://rtionline.karnataka.gov.in/index.php?lan=E" target="_blank">
            <img src="images/dept_img/enimages/RTI.jpg" alt="RTI" class="img6 w-100 wow zoomIn" data-wow-delay="0.7s"  style="visibility: hidden; animation-delay: 0.7s; animation-name: none;"/>
          </a>
          </div>
        </div>
    

    </div>
  </section>
<!---------------------------------------------->
<Section class="third-con">
  <div class="container newheader6">

    <div class="row sec-row">

      <div class="col-md-8">
        <a href="https://ipgrs.karnataka.gov.in/" target="_blank">
     <img src="images/dept_img/enimages/IPGRS.jpg" class="bigimg w-100 wow zoomIn"  style="visibility: hidden; animation-name: none;" />
    </a>
    </div>

    <div class="col-md-4">

      <a href="https://mahitikanaja.karnataka.gov.in/" target="_blank">
      <img src="images/dept_img/enimages/Mahithi Kanaja.jpg" alt="MK"  class="img1 w-50 wow zoomIn" data-wow-delay="0.3s" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/>  </a>

      <a href="https://ekannada.karnataka.gov.in/" target="_blank">
      <img src="images/dept_img/enimages/E Kannada.jpg" alt="ekannada"  class="img2 w-75 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/>  </a>
      
     </div>


    </div>
 </Section>

  <!------------------------------------------->
  <Section class="fourth-con">
    <div class="container newheader5">
        <div class="row sec-row">

          <div class="col-md-4">
            <a href="https://ssp.karnataka.gov.in/" target="_blank">
            <img src="images/dept_img/enimages/SSP.jpg" alt="SSP" class="img4 w-100 wow zoomIn" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/>  </a>
          </div>

          <div class="col-md-4">
            <a href="https://nad.gov.in/" target="_blank">
            <img src="images/dept_img/enimages/NAD.jpg" alt="NAD"  class="img5 w-50 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/> </a>
          </div>

          <div class="col-md-4">
            <a href="https://suvidha.karnataka.gov.in/" target="_blank">
            <img src="images/dept_img/enimages/Suvidha.jpg" alt="Suvidha" class="img6 w-100 wow zoomIn" data-wow-delay="0.7s"  style="visibility: hidden; animation-delay: 0.7s; animation-name: none;" /> </a>
          </div>
        </div>
    

    </div>
  </section>

  <!---------------------------------------------->
<Section class="third-con">
  <div class="container newheader6">

    <div class="row sec-row">

      <div class="col-md-8">
        <a href="https://fruits.karnataka.gov.in/" target="_blank">
        <img src="images/dept_img/enimages/Fruits.jpg" class="bigimg w-100 wow zoomIn"  style="visibility: hidden; animation-name: none;"/>
     </a>
    </div>

    <div class="col-md-4">
      <a href="https://kppp.karnataka.gov.in" target="_blank">
      <img src="images/dept_img/enimages/E PROC New (1).jpg" alt="eproc" class="img1 w-50 wow zoomIn" data-wow-delay="0.3s" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/></a>

      <a href="https://esahamathi.karnataka.gov.in/" target="_blank">
      <img src="images/dept_img/enimages/E-Sahamathi.jpg" alt="webportal" class="img2 w-75 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/>
    </a>

     </div>


    </div>
 </Section>

  <!------------------------------------------->
    <!------------------------------------------->
    <Section class="fourth-con">
      <div class="container newheader5">
          <div class="row sec-row">
  
            <div class="col-md-4">
              <a href="https://ceg.karnataka.gov.in/aadhaar/public/english" target="_blank">
              <img src="images/dept_img/enimages/Aadhar.jpg" alt="aadhar" class="img4 w-100 wow zoomIn" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/>
            </a>
            </div>

            <div class="col-md-4">
              <a href="https://capacitybuilding.karnataka.gov.in/en" target="_blank">
              <img src="images/dept_img/enimages/Capacity Building.jpg" alt="Capacity Building"  class="img5 w-50 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/>
            </a>
            </div>

            <div class="col-md-4">
              <a href="https://ceg.karnataka.gov.in/krdh/public/" target="_blank">
              <img src="images/dept_img/enimages/KRDH (1).jpg" alt="krdh" class="img6 w-100 wow zoomIn" data-wow-delay="0.7s"  style="visibility: hidden; animation-delay: 0.7s; animation-name: none;"/>
            </a>
            </div>
          </div>
      
  
      </div>
    </section>
  
    <!---------------------------------------------->
 
      <!---------------------------------------------->
<Section class="third-con">
  <div class="container newheader6">

    <div class="row sec-row">

      <div class="col-md-8">
        <a href="https://kutumba.karnataka.gov.in/en/Index" target="_blank">
     <img src="images/dept_img/enimages/Kutumba.jpg" class="bigimg w-100 wow zoomIn"  style="visibility: hidden; animation-name: none;"/> </a>
    </div>

    <div class="col-md-4">

      <a href="seclan.html" target="_blank">
      <img src="images/dept_img/enimages/SecLAN 2.0.jpg" alt="Seclan" class="img1 w-50 wow zoomIn" data-wow-delay="0.3s" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/> </a>

      <a href="sdc.html" target="_blank">
      <img src="images/dept_img/enimages/SDC.jpg" alt="SDC" class="img2 w-75 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/> </a>
      
     </div>


    </div>
 </Section>

  <!------------------------------------------->
     <!------------------------------------------->
     <Section class="fourth-con">
      <div class="container newheader5">
          <div class="row sec-row">
  
            <div class="col-md-4">
              <a href="https://dbt.karnataka.gov.in/" target="_blank">
              <img src="images/dept_img/enimages/DBT.jpg" alt="dbt" class="img4 w-100 wow zoomIn" style="visibility: hidden; animation-delay: 0.3s; animation-name: none;"/>
            </a>
            </div>

            <div class="col-md-4">
              <a href="https://ceg.karnataka.gov.in/kswan/public/english" target="_blank">
              <img src="images/dept_img/enimages/KSWAN.jpg" alt="KSWAN" class="img5 w-50 wow zoomIn" data-wow-delay="0.5s" style="visibility: hidden; animation-delay: 0.5s; animation-name: none;"/>
            </a>
            </div>

             <div class="col-md-4">
              <a href="https://karnataka.mygov.in/" target="_blank">
              <img src="images/dept_img/enimages/Mygov.jpg" alt="mygov" class="img6 w-100 wow zoomIn" data-wow-delay="0.7s"  style="visibility: hidden; animation-delay: 0.7s; animation-name: none;"/>
            </a>
            </div>
          </div>
      
  
      </div>
    </section>
<!---------------------------------------------->



 <button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa-sharp fa-solid fa-arrow-up"></i></button>
<!------------------------>

<!----------------------------------------------------------------->
<div>
<div class="container" id="container_owl">
<div class="owl-carousel owl-theme owl-links">

  <a href="https://karnataka.gov.in/gokdirectory/en" target="_blank">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/CONTACT-DIRECTORY.png" id="manual">
      Govt Contact Manual
    </div>
   </a>

   <div data-toggle="modal" data-target="#myModal_screen1">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/IMPORTENT-WEBSITES.png">
      Important Websites
    </div> 
   </div>  
    
    <div data-toggle="modal" data-target="#myModal_screen2">
     <div class="item1">
       <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/ceg11.png">
       e-Governance Websites
     </div>
    </div>

    <div data-toggle="modal" data-target="#myModal_screen3">
     <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/E-SERVICES.png">
      e-Service Websites
     </div>
    </div> 

    <div data-toggle="modal" data-target="#myModal_screen4">
     <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/STATISTICS-WEBSITES.png">
      Statistics Websites
     </div>
    </div> 

  


         <div>
      <a href="https://apps.karnataka.gov.in/kn"  target="_blank">
     <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/MOBILE-APPS.png">
      Government Apps
     </div>
     </a>
    </div> 


   <div data-toggle="modal" data-target="#myModal_screen5">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/CENTREL-GOVT-WEBSITES.png">
      Central Govt Websites
    </div>
   </div> 

   <div data-toggle="modal" data-target="#myModal_screen6">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/TECHNICLE-WEBSITES.png">
      Technical Websites
    </div>
   </div> 

 
   <div data-toggle="modal" data-target="#myModal_screen7">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/KANNADA-WEBSITES.png">
       Kannada websites
    </div>
   </div> 

  <div data-toggle="modal" data-target="#myModal_screen8">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/COMMISSIONS.png">
       Commission
    </div>
   </div> 
    
  <div data-toggle="modal" data-target="#myModal_screen9">  
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/LAW-COURT.png">
      Law/Court
    </div>
   </div> 

   <div data-toggle="modal" data-target="#myModal_screen10">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/DOWNLOADS.png">
      Downloads
    </div>
   </div> 

   <a href="https://www.kstdc.co/" target="_blank">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/TOURIST-WEBSITE.png">
      Tourist Websites
    </div>
   </a> 

   <a href="https://ceg.karnataka.gov.in/frontend/opt1/pdfs/HOLIDAYSLIST2024.pdf" target="_blank">
    <div class="item1">
      <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/GOVERNMENT-HOLLIDAY.png">
       Government Holidays
    </div>
   </a> 

    
</div>
</div>
</div>
<!----------------------------------------------------------------->

 <div class="modal " id="myModal_screen1" role="dialog">
    <div class="modal-dialog">
  
       <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Important Websites</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">

         <!----- <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://karnataka.gov.in/department/kn" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/important_websites/webdirectory.png">
              <p>Web-Directory</p>
            </a>
          </div>---->

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="http://rajbhavan.karnataka.gov.in" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/important_websites/karnataka_rajbhavan.png">
              <p>Raj-Bhavan</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://cm.karnataka.gov.in/" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/important_websites/vidan_souda.png">
            <p>Chief Minister</p>
           </a> 
          </div>

		  
		    <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="http://www.kla.kar.nic.in/assembly/assembly.htm" target="_blank">
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/important_websites/vidan_sabhe.png">
            <p>Legislative Assembly</p>
           </a> 
          </div>
       

        </div>

        <div class="row">
           
          
          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="http://www.kla.kar.nic.in/council/" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/important_websites/vidan_parishat.png">
            <p>Legislative Council</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://www.csogok.gov.in/" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/important_websites/vidan_souda.png">
            <p>Chief Secretary</p>
           </a> 
          </div>

          
        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
<!--------------------------------->
  <div class="modal " id="myModal_screen2" role="dialog">
 <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">e - Governance</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">
  <div class="col-md-3 col-sm-6 col-xs-12 sbox" id="modal_icons" style="background-color:lavenderblush;text-align: center;">
             <a href="https://ceg.karnataka.gov.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/ceg11.png" style="width:60%;border-radius:50px;border:10px solid 80808008;display:flex;margin-left:25%;">
              <p style="text-align:center;">C.E.G</p>
            </a>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://webportal.karnataka.gov.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/webportal logo.png">
              <p>Web Portal</p>
            </a>
          </div>

           <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://ceg.karnataka.gov.in/aadhaar/public/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/adhaar.png">
              <p>Aadhaar</p>
            </a>
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://eofficecitizen.karnataka.gov.in"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/eoffice.png">
            <p>e-Office</p>
           </a> 
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://eproc.karnataka.gov.in/eprocportal/pages/index.jsp?language=kn"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/esangraha.png">
            <p>e-Procurement</p>
           </a> 
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;;text-align: center;">
           <a href="https://hrms.karnataka.gov.in/" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/hrms.png">
            <p>HRMS</p>
           </a> 
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://ceg.karnataka.gov.in/krdh/public/" target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/krdh.png">
            <p>KRDH</p>
           </a> 
          </div>

          <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://karunadu.karnataka.gov.in/KSWAN/pages/home.aspx"  target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/kswan.png">
            <p>KSWAN</p>
           </a> 
          </div>

           <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://dpar.karnataka.gov.in" target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/krdh.png">
            <p>DPAR</p>
           </a> 
          </div>

           <div class="col-md-3 col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
            <a href="https://ceg.karnataka.gov.in/ksdc/public/" target="_blank"> 
             <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/ceg/sdc.png" style="width:60%;border-radius:50px;border:10px solid 80808008;display:flex;margin-left:25%;">
             <p>KSDC</p>
            </a> 
          </div>


           <div class="col-md-3 col-sm-6 col-xs-12 sbox" id="modal_icons" style="background-color:lavenderblush;text-align: center;">
             <a href="https://karnataka.data.gov.in" target="_blank">
               <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/icons/kodi.jpg" style="width:60%;border-radius:50px;border:10px solid 80808008;display:flex;margin-left:25%;margin-top:20px;">
              <p style="text-align:center;">Open Data</p>
            </a>
          </div>

           <div class="col-md-3 col-sm-6 col-xs-12 sbox" id="modal_icons" style="background-color:lavender;text-align: center;">
             <a href="https://digilocker.gov.in" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/icons/digi.jpg" style="width:60%;border-radius:50px;border:10px solid 80808008;display:flex;margin-left:25%;margin-top:20px;">
              <p style="text-align:center;">Digilocker</p>
            </a>
          </div>

              <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="http://mahitikanaja.karnataka.gov.in/Department" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/eservices/kar.png">
            <p>Mahiti Kanaja</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="http://nad.gov.in/Department" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1//images/icons/nad.png" style="width:60%;border-radius:50px;border:10px solid 80808008;display:flex;margin-left:25%;margin-top:20px;">
            <p style="text-align:center;">NAD</p>
           </a> 
          </div>
		  
		     <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://ipgrs.karnataka.gov.in" target="_blank">  
            <img src="https://egovernance.karnataka.gov.in/frontend/opt1/images/Janaspandana-logo.png" style="width:60%;border-radius:50px;border:10px solid 80808008;display:flex;margin-left:25%;margin-top:13px;">
            <p>IPGRS</p>
           </a> 
          </div>
		  
		  
		  <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://ssp.karnataka.gov.in" target="_blank">  
            <img src="https://egovernance.karnataka.gov.in/frontend/opt1/images/kar_logo.png" style="width:60%;border-radius:50px;border:10px solid 80808008;display:flex;margin-left:25%;margin-top:13px;">
            <p>State Scholarship Portal </p>
           </a> 
          </div>
		  
		  
		  

        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
	</div>
<!----------------------------------->
<!--------------------------------->
 <div class="modal " id="myModal_screen3" role="dialog">
    <div class="modal-dialog">
	     <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">e - Services</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="http://www.sakala.kar.nic.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/eservices/sakala.png">
              <p>Sakala</p>
            </a>
          </div>

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://sevasindhu.karnataka.gov.in/Sevasindhu/Kannada?ReturnUrl=%2F" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/eservices/kar.png">
              <p>Seva Sindhu</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://erajyapatra.karnataka.gov.in/(S(trrt4chio0tzmuy54rnz01x3))/default.aspx?AcceptsCookies=yes"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/eservices/kar.png">
            <p>e-Gazette</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://rtionline.karnataka.gov.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/eservices/kar.png">
            <p>Online RTI</p>
           </a> 
          </div>

        </div>

        <div class="row">
          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://espandana.karnataka.gov.in" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/eservices/espandana.png">
            <p>e-Spandana</p>
           </a> 
          </div>

        
          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="http://mahitikanaja.karnataka.gov.in/Department" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/eservices/kar.png">
            <p>Mahiti Kanaja</p>
           </a> 
          </div>
          

        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      </div>
	  </div>
<!----------------------------------->
<!--------------------------------->
 <div class="modal " id="myModal_screen4" role="dialog">
    <div class="modal-dialog">
	   <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Statistics</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://esamiksha.gov.in/Karnataka/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/e-pragathi.png">
              <p>e-Pragathi</p>
            </a>
          </div>

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://etaal.gov.in/etaal2/auth/default.aspx" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/e_taal.png">
              <p>e-Taal</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://karnataka.data.gov.in"  target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/data.png">
            <p>DATA</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://gazetteer.karnataka.gov.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/gazette.png">
            <p>Karnataka Gazette</p>
           </a> 
          </div>

        </div>

        <div class="row">

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="http://stgpratibimba.karnataka.gov.in/cmdbstg1/public/" target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/Statistics/pratibimba_cm_dashbaord.png">
            <p>CM Dashboard</p>
           </a> 
          </div>

        

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
          </div>
        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
	  </div>
	  </div>
<!-----------------------------------><!--------------------------------->
 <div class="modal " id="myModal_screen5" role="dialog">
    <div class="modal-dialog">
	 
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Central Government Websites</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://loksabha.nic.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/central_govt_websites/parliment_samsattu.png">
              <p>Parliament</p>
            </a>
          </div>

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://presidentofindia.nic.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/central_govt_websites/presidents_office.png">
              <p>Presidents Office</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://www.pmindia.gov.in/en/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/central_govt_websites/prime_ministers.png">
            <p>Prime Ministers Office</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://portal2.passportindia.gov.in/AppOnlineProject/welcomeLink"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/central_govt_websites/passport_seva.png">
            <p>Passport Seva</p>
           </a> 
          </div>

        </div>

        <div class="row">

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://uidai.gov.in/" target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/central_govt_websites/adhaar.png">
            <p>Aadhaar</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
            <a href="https://karunadu.karnataka.gov.in/karnatakabhavan/pages/home.aspx"  target="_blank">  
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/central_govt_websites/karnataka_bhavan.png">
            <p>Karnataka Bhavan</p>
           </a> 
          </div>

         


  
        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
	</div>
	  </div>
<!-----------------------------------><!--------------------------------->
 <div class="modal " id="myModal_screen6" role="dialog">
    <div class="modal-dialog">
	 <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Technical Websites</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://www.cdac.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/technical_websites/cdac.png">
              <p>CDAC</p>
            </a>
          </div>

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://www.nic.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/technical_websites/nic.png">
              <p>NIC</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="http://www.stqc.gov.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/technical_websites/stqc.png">
            <p>STQC</p>
           </a> 
          </div>

         

        </div>

        <div class="row">

    

        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
</div>
	  </div>
<!-----------------------------------><!--------------------------------->
 <div class="modal " id="myModal_screen7" role="dialog">
    <div class="modal-dialog">
	   
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Kannada Websites</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://kannadasiri.karnataka.gov.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/kannada_websites/kannada_culure_dept.png">
              <p>Kannada & Culture</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://kannadasahithyaparishattu.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/kannada_websites/kannada_sahitya_parishat.png">
            <p>Sahitya Parishat</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://kanaja.karnataka.gov.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/kannada_websites/kanaja.png">
            <p>kanaja</p>
           </a> 
          </div>


          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://kannadapraadhikaara.karnataka.gov.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/kannada_websites/kannada_abhiruddi_pradikar.png">
              <p>Development Authority</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://ekannada.karnataka.gov.in/"  target="_blank"> 
           <img class="ekan" src="https://ceg.karnataka.gov.in/frontend/opt1/images/e-kanada-logo.png" style="width:50%;">
            <p>EKannada</p>
           </a> 
          </div>

         

        </div>

        <div class="row">

    

        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
	</div>
	  </div>
<!-----------------------------------><!--------------------------------->
 <div class="modal " id="myModal_screen8" role="dialog">
    <div class="modal-dialog">
	   <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Commissions</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://kshrc.karnataka.gov.in/english" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/human_rights_kar.png">
              <p>Karnataka State Human Right Commission</p>
            </a>
          </div>

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://kerc.karnataka.gov.in" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/all_ayoga.png">
              <p>Karnataka State Electricity commission</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://karunadu.karnataka.gov.in/jnanaayoga/Pages/home.aspx"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/all_ayoga.png">
            <p>Karnataka Knowledge Commission</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://ceo.karnataka.gov.in"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/all_ayoga.png">
            <p>Karnataka State Election Commission</p>
           </a> 
          </div>

      
        </div>

        <div class="row">

            

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://kslsa.kar.nic.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/all_ayoga.png">
            <p>Karnataka Legal Authority</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://kscpcr.karnataka.gov.in/english"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/all_ayoga.png">
            <p>Karnataka State Child Rights Commission</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="http://www.kscw.kar.nic.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/all_ayoga.png">
            <p>Karnataka Women's Commission</p>
           </a> 
          </div>

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
          <a href="https://kscdrc.karnataka.gov.in/english"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/commissions_websites/all_ayoga.png">
            <p>Karnataka State Consumer Disputes Redressal Commission</p>
           </a> 
          </div>

    

        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
	</div>
	  </div>
<!-----------------------------------><!--------------------------------->
 <div class="modal " id="myModal_screen9" role="dialog">
    <div class="modal-dialog">
	  <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Law Courts</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
             <a href="https://main.sci.gov.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/law_websites/supreeem_court.png">
              <p>Supreme Court</p>
            </a>
          </div>

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://karnatakajudiciary.kar.nic.in/" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/law_websites/high_1_court.png">
              <p>High Court</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://districts.ecourts.gov.in/karnataka"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/law_websites/district_courts.png">
            <p>District Courts</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://cgat.gov.in/catlive/index.php"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/law_websites/cat.png">
            <p>Central Administrative Tribunal</p>
           </a> 
          </div>

        </div>

        <div class="row">

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://ksat.karnataka.gov.in/"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/law_websites/dpar.png">
            <p>Karnataka State Administrative Tribunal</p>
           </a> 
          </div>
    

        </div>

      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
	</div>
	  </div>
<!-----------------------------------><!--------------------------------->
 <div class="modal " id="myModal_screen10" role="dialog">
    <div class="modal-dialog">
	      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Downloads</h4>
        </div>

        <div class="modal-body">
          <div class="container-fluid">
        <div class="row">


        

           <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
             <a href="https://ceg.karnataka.gov.in/frontend/opt1/application_download/nudi_6.0_setup.exe" target="_blank">
              <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/downloads_websites/nudi.png">
              <p>NUDI</p>
            </a>
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavender;text-align: center;">
           <a href="https://www.cdac.in/index.aspx?id=ev_corp_gist_go_translate"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/downloads_websites/go_translate_cdac.png">
            <p>GO Translate CDAC</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://ceg.karnataka.gov.in/frontend/opt1/application_download/setup_espeak.exe"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/downloads_websites/e_speak.png">
            <p>e-Speak</p>
           </a> 
          </div>

          <div class="col-md-3  col-sm-6 col-xs-12 sbox" style="background-color:lavenderblush;text-align: center;">
           <a href="https://play.google.com/store/apps/details?id=com.voicenotes.kannada&hl=en"  target="_blank"> 
            <img src="https://ceg.karnataka.gov.in/frontend/opt1/images/modal_icons/downloads_websites/kan_voice_notes.png">
            <p>kannada Voice Notes</p>
           </a> 
          </div>


         

        </div>

        <div class="row">

    

        </div>
      </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
	</div>
	  </div>
<!-----------------------------------><!--------------------------------->


<!----------------------------------->
 
 <!---------------------------------------  Parallax4  ----------------------------------------->

 <footer class="footer_section">

  <div class="container newheader">
      <div class="footer-content pt-5 pb-5">
          <div class="row sec-row">
              <div class="col-xl-4 col-sm-4 col-md-4 col-xs-6 col-lg-3 ft_col">
                  <div class="footer-widget">
                      <div class="footer-text">
                          <div class="footer-widget-heading">
                              <h3 class="contact_us"> About Us</h3>
                              <hr>
                          </div>
                          <p class="pls">Government of Karnataka is pioneer and exemplary model in the governance of Information and Communication Technology (ICT) and is active in implementing e-governance initiatives in the country. e-Governance division is a part of the Department of Personnel and Administrative Reforms (DPAR).</p>
                      </div>

                  </div>
              </div>
              <div class="col-xl-4 col-sm-4 col-md-4 col-xs-6 col-lg-3 ft_col">
                  <div class="footer-widget">
                      <div class="footer-widget-heading">
                          <h3 class="contact_us">Website Policies & Guidelines</h3>
                          <hr>
                      </div>
                      <ul class="footer1_p_ul">
                        <li><a href="policies.html">Copyright Policy</a></li>
                        <li><a href="policies.html">Hyperlinking Policy</a></li>
                        <li><a href="policies.html">Security Policy</a></li>
                        <li><a href="policies.html">Terms & Conditions</a></li>
                      </ul>

                      <ul class="footer2_p_ul">
                         
                        <li><a href="policies.html">Privacy Policy</a></li>
                        <li data-toggle="modal" data-target="#myModalf8">Help</li>
                        <li data-toggle="modal" data-target="#myModal_screen" class="screen">Screen Reader</li>
                        <li><a href="guidelines.html">Guidelines</a></li> </ul>


                  </div>
              </div>

             

              <div class="col-xl-4 col-sm-4 col-md-4 col-xs-6 col-lg-3 ft_col">
                <div class="footer-widget">
                    <div class="footer-text">
                        <div class="footer-widget-heading">
                            <h3 class="contact_us"> Disclaimer</h3>
                            <hr>
                        </div>
                        <p class="pls">Please note that this page also provides links to the websites / web pages of Govt. Ministries/Departments/Organisations.The content of these websites are owned by the respective organisations and they may be contacted for any further information or suggestion.</p>
                    </div>

                </div>
            </div>

            <div class="row last-div">

              <div class="col-md-4">Last Updated: 26-12-2023</div>
              <div class="col-md-4"></div>
              <div class="col-md-4">Version : CeG/KRN 2.0.0 </div>

            </div>

            <p class="content">CONTENT OWNED BY : Centre for e - Governance, Government of Karnataka</p>

            <p class="content">Designed, Developed & Hosted By : CENTRE FOR e-GOVERNANCE, Government of Karnataka ©2023, All Rights Reserved.</p>

          </div>
      </div>
  </div>
</footer>


<!------------------------------------>
<div class="modal fade in" id="myModalf8" role="dialog">
  <div class="modal-dialog">
  
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Help</h4>
      </div>
      <div class="modal-body">
        
        <h6 style="text-decoration: underline;" class="copy_header">INFORMATION SEARCH:</h6>

         <p> to help users access information within the website, a “search here” option is been provided. here, the option to type in Kannada is made available. while searching, usage of Unicode font is compulsory. option to search in English is also provided. </p>

        <h6 style="text-decoration: underline;" class="copy_header">INTERNET ACCESSIBILITY</h6> 

          <p>if the internet is slow or unavailable, there may be a modification in website design or some subpages may not open. </p>

        <p></p><br>

        <div class="scroll-table1"><div class="guide-text"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></div><div class="scroll-table"><table id="tablehelp" class="border table-bordered table" border="1"> <caption>Help of Various File formats :</caption> <tbody> <tr> <th>Document Type</th> <th>Download</th> </tr> <tr class="even"> <td>PDF content</td> <td> <img src="https://labour.gov.in/sites/default/files/pdf.png" alt="image"><a href="http://get.adobe.com/reader/" target="_blank" title="Opens in a new window"> Adobe Acrobat Reader</a> (External website that opens in a new window) </td> </tr> <tr class="odd"> <td>Word files</td> <td><img src="https://labour.gov.in/sites/default/files/Word.png" alt="image">  <a href="http://www.microsoft.com/downloads/en/details.aspx?familyid=3657CE88-7CFA-457A-9AEC-F4F827F20CAC&amp;displaylang=en" target="_blank" title="Opens in a new window"> Word Viewer (in any version till 2003)</a> - External website that opens in a new window<br> <a href="http://www.microsoft.com/downloads/en/details.aspx?FamilyID=c8378bf4-996c-4369-b347-73edbd03aaf0&amp;displaylang=EN" target="_blank" title="Opens in a new window">Microsoft Office Compatibility Pack for Word (for 2007 version)</a> - External website that opens in a new window </td> </tr> <tr class="even"> <td>Excel files</td> <td> <img src="https://labour.gov.in/sites/default/files/Excel.png" alt="image">  <a href="http://www.microsoft.com/downloads/en/details.aspx?FamilyId=428D3727-43AB-4F24-90B7-A94784AF71A4&amp;displaylang=en" target="_blank" title="Opens in a new window"> Excel Viewer 2003 (in any version till 2003)</a> - External website that opens in a new window<br> <a href="http://www.microsoft.com/downloads/en/details.aspx?familyid=941b3470-3ae9-4aee-8f43-c6bb74cd1466&amp;displaylang=en" target="_blank" title="Opens in a new window">Microsoft Office Compatibility Pack for Excel (for 2007 version)</a> - External website that opens in a new window </td> </tr> <tr class="odd"> <td>PowerPoint presentations</td> <td><img src="https://labour.gov.in/sites/default/files/powerpoint.png" alt="image">  <a href="http://www.microsoft.com/downloads/en/details.aspx?FamilyId=428D5727-43AB-4F24-90B7-A94784AF71A4&amp;displaylang=en" target="_blank" title="Opens in a new window"> PowerPoint Viewer 2003 (in any version till 2003)</a> - External website that opens in a new window<br> <a href="http://www.microsoft.com/downloads/en/details.aspx?familyid=941b3470-3ae9-4aee-8f43-c6bb74cd1466&amp;displaylang=en" target="_blank" title="Opens in a new window">Microsoft Office Compatibility Pack for PowerPoint (for 2007 version)</a> - External website that opens in a new window </td> </tr> <tr class="even"> <td>Flash content</td> <td> <img src="https://labour.gov.in/sites/default/files/Flash.png" alt="image"> <a href="http://get.adobe.com/flashplayer/" target="_blank" title="Opens in a new window">Adobe Flash Player </a>(External website that opens in a new window) </td> </tr> <tr class="odd"><td>Audio Files</td> <td> <img src="https://labour.gov.in/sites/default/files/red.png" alt="image"> <a href="http://windows.microsoft.com/en-US/windows/downloads/windows-media-player" target="_blank" title="Opens in a new window">Windows Media Player </a>(External website that opens in a new window) </td> </tr> </tbody> </table></div></div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
    
  </div>
</div>
   <!--------------------------------------------->
    
   <script src="js/wow.min.js"></script>
   
   <script src=" https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.5.4/umd/popper.min.js"></script>

    <script type="text/javascript" src="owl/owl.carousel.js"></script>

 <!---------------footer------------------------>
 
<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>




 <script>
  $(document).ready(function(e){
        let upto=0;
    let upto1=0;
    let upto2=0;
    let upto3=0;
        let counts=setInterval(updated);
    let counts1=setInterval(updated1);
    let counts2=setInterval(updated2);
    let counts3=setInterval(updated3);
    
    function updated(){
  
        var count= document.getElementById("counter");
        pausecomp(50);
        count.innerHTML=++upto;
        //break
        if(upto===31)
        {
            clearInterval(counts); //2
        }
  
  
  
      
    }
    function updated1()
    {
    var count1= document.getElementById("counter1");
        pausecomp(50);
        count1.innerHTML=++upto1;
        //alert(upto1);
        if(upto1===13)
        {
            clearInterval(counts1); //2
        }
  
  
    }
    function updated2()
    {
        var count2= document.getElementById("counter2");
        pausecomp(50);
        count2.innerHTML=++upto2;
        //alert(upto2);
        if(upto2===27)
        {
            clearInterval(counts2); //2
        }
  
    }
  

    });

    function pausecomp(millis)
{
    var date = new Date();
    var curDate = null;
    do { curDate = new Date(); }
    while(curDate-date < millis);
}
     
  </script>

 <!--------------------------------------------->
 <script src="js/colorchange.js"></script>

 <script>
  // Get the button
  let mybutton = document.getElementById("myBtn");
  
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function() {scrollFunction()};
  
  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      mybutton.style.display = "block";
    } else {
      mybutton.style.display = "none";
    }
  }
  
  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
  </script>

 
<script type="text/javascript">
$('.owl-carousel').owlCarousel({
loop:true,
margin:10,
nav:true,
autoplay:true,
responsive:{
   0:{
       items:1
   },
   320:{
     items:1
   },
   550:{
     items:2
   },
   600:{
       items:2
   },
   767:{
     items:2
   },
   991:{
     items:3
   },
   1000:{
       items:3
   },
   1199:{
     items:5
   },
}
})
</script>



<script>
    $('.navbar').navbarDropdown({
  theme: 'bs5',
  trigger: 'mouseover'
});
</script>


 <!--------------------------------------------->




    </body>
    </html>
    